// background.js
export {};
